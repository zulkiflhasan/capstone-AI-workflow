from pathlib import Path
import pandas as pd

REQUIRED_COLUMNS = {
    "date",
    "country",
    "revenue",
    "purchases",
    "stream_views",
    "customer_id",
}


def load_transactions(path: str | Path) -> pd.DataFrame:
    """Load and validate transaction data for repeatable automation."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Data file not found: {path}")

    df = pd.read_csv(path, parse_dates=["date"])
    missing = REQUIRED_COLUMNS.difference(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    if df.empty:
        raise ValueError("The transaction dataset is empty.")

    numeric = ["revenue", "purchases", "stream_views"]
    df[numeric] = df[numeric].apply(pd.to_numeric, errors="coerce")
    if df[numeric].isna().any().any():
        raise ValueError("Numeric fields contain invalid values.")

    return df.sort_values("date").reset_index(drop=True)


def build_monthly_features(df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate transactions and create time-series forecasting features."""
    monthly = (
        df.assign(month=df["date"].dt.to_period("M").dt.to_timestamp())
        .groupby(["country", "month"], as_index=False)
        .agg(
            revenue=("revenue", "sum"),
            purchases=("purchases", "sum"),
            stream_views=("stream_views", "sum"),
            active_customers=("customer_id", "nunique"),
        )
        .sort_values(["country", "month"])
    )

    monthly["previous_revenue"] = monthly.groupby("country")["revenue"].shift(1)
    monthly["target_revenue"] = monthly.groupby("country")["revenue"].shift(-1)
    monthly["month_number"] = monthly["month"].dt.month
    monthly["year"] = monthly["month"].dt.year

    return monthly.dropna(subset=["previous_revenue", "target_revenue"]).reset_index(drop=True)
