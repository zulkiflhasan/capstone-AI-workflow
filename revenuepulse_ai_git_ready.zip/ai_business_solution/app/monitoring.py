from __future__ import annotations

from pathlib import Path
from datetime import datetime, timezone
import json
import statistics


def write_prediction_log(
    log_path: str | Path,
    *,
    country: str,
    target_month: str,
    prediction: float,
    model_version: str,
    runtime_ms: float,
    input_summary: dict,
) -> None:
    path = Path(log_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "country": country,
        "target_month": target_month,
        "prediction": round(float(prediction), 2),
        "model_version": model_version,
        "runtime_ms": round(float(runtime_ms), 3),
        "input_summary": input_summary,
    }

    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record) + "\n")


def read_prediction_logs(log_path: str | Path) -> list[dict]:
    path = Path(log_path)
    if not path.exists():
        return []
    records = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            records.append(json.loads(line))
    return records


def detect_prediction_drift(
    records: list[dict],
    training_mean: float,
    threshold_ratio: float = 0.30,
) -> dict:
    if not records:
        return {"drift_detected": False, "reason": "No prediction logs available."}

    recent_mean = statistics.fmean(r["prediction"] for r in records[-30:])
    denominator = max(abs(training_mean), 1.0)
    deviation_ratio = abs(recent_mean - training_mean) / denominator

    return {
        "drift_detected": deviation_ratio > threshold_ratio,
        "recent_mean": recent_mean,
        "training_mean": training_mean,
        "deviation_ratio": deviation_ratio,
    }
