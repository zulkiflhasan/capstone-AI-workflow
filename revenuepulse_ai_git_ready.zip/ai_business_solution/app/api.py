from __future__ import annotations

from pathlib import Path
import os
import time
import pandas as pd
from flask import Flask, jsonify, request

from app.data_ingestion import load_transactions, build_monthly_features
from app.model import load_model, load_metadata, build_prediction_rows, predict_revenue
from app.monitoring import write_prediction_log, read_prediction_logs, detect_prediction_drift

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_PATH = Path(os.getenv("DATA_PATH", BASE_DIR / "data" / "transactions.csv"))
MODEL_PATH = Path(os.getenv("MODEL_PATH", BASE_DIR / "models" / "best_model.joblib"))
METADATA_PATH = Path(os.getenv("METADATA_PATH", BASE_DIR / "models" / "model_metadata.json"))
LOG_PATH = Path(os.getenv("LOG_PATH", BASE_DIR / "logs" / "predictions.log"))

app = Flask(__name__)


def get_resources():
    model = load_model(MODEL_PATH)
    metadata = load_metadata(METADATA_PATH)
    data = load_transactions(DATA_PATH)
    monthly = build_monthly_features(data)
    return model, metadata, monthly


@app.get("/health")
def health():
    return jsonify({"status": "healthy", "service": "RevenuePulse AI"}), 200


@app.post("/predict")
def predict():
    start = time.perf_counter()
    payload = request.get_json(silent=True) or {}

    country = str(payload.get("country", "")).strip()
    target_month = str(payload.get("target_month", "")).strip()

    if not country or not target_month:
        return jsonify({"error": "country and target_month are required"}), 400

    try:
        pd.Period(target_month, freq="M")
        model, metadata, monthly = get_resources()

        valid_countries = set(monthly["country"].unique()) | {"ALL"}
        if country not in valid_countries:
            return jsonify(
                {"error": "Unknown country", "valid_countries": sorted(valid_countries)}
            ), 400

        rows = build_prediction_rows(monthly, country, target_month)
        prediction = predict_revenue(model, rows)
        runtime_ms = (time.perf_counter() - start) * 1000

        write_prediction_log(
            LOG_PATH,
            country=country,
            target_month=target_month,
            prediction=prediction,
            model_version=metadata["model_version"],
            runtime_ms=runtime_ms,
            input_summary={
                "countries_scored": int(len(rows)),
                "feature_count": int(rows.shape[1]),
            },
        )

        return jsonify(
            {
                "country": country,
                "target_month": target_month,
                "predicted_revenue": round(prediction, 2),
                "model_name": metadata["best_model"],
                "model_version": metadata["model_version"],
            }
        ), 200

    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    except Exception as exc:
        return jsonify({"error": f"Prediction service failure: {exc}"}), 500


@app.get("/monitor")
def monitor():
    try:
        metadata = load_metadata(METADATA_PATH)
        records = read_prediction_logs(LOG_PATH)
        status = detect_prediction_drift(
            records,
            training_mean=float(metadata["training_target_mean"]),
        )
        return jsonify(status), 200
    except Exception as exc:
        return jsonify({"error": f"Monitoring failure: {exc}"}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
