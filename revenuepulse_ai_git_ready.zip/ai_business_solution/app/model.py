from __future__ import annotations

from pathlib import Path
import json
import joblib
import pandas as pd

FEATURE_COLUMNS = [
    "country",
    "month_number",
    "year",
    "previous_revenue",
    "purchases",
    "stream_views",
    "active_customers",
]


def load_model(model_path: str | Path):
    path = Path(model_path)
    if not path.exists():
        raise FileNotFoundError(f"Model not found: {path}")
    return joblib.load(path)


def load_metadata(metadata_path: str | Path) -> dict:
    path = Path(metadata_path)
    if not path.exists():
        raise FileNotFoundError(f"Metadata not found: {path}")
    return json.loads(path.read_text())


def latest_country_features(monthly_df: pd.DataFrame, country: str) -> pd.DataFrame:
    if country == "ALL":
        latest = monthly_df.sort_values("month").groupby("country", as_index=False).tail(1)
    else:
        latest = monthly_df[monthly_df["country"] == country].sort_values("month").tail(1)

    if latest.empty:
        raise ValueError(f"No data available for country: {country}")
    return latest


def build_prediction_rows(monthly_df: pd.DataFrame, country: str, target_month: str) -> pd.DataFrame:
    target = pd.Period(target_month, freq="M").to_timestamp()
    latest = latest_country_features(monthly_df, country).copy()

    rows = pd.DataFrame(
        {
            "country": latest["country"].values,
            "month_number": target.month,
            "year": target.year,
            "previous_revenue": latest["revenue"].values,
            "purchases": latest["purchases"].values,
            "stream_views": latest["stream_views"].values,
            "active_customers": latest["active_customers"].values,
        }
    )
    return rows[FEATURE_COLUMNS]


def predict_revenue(model, rows: pd.DataFrame) -> float:
    predictions = model.predict(rows)
    return float(sum(predictions))
