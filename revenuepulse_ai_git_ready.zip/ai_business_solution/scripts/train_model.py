from pathlib import Path
import json
import sys

import joblib
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

BASE_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE_DIR))

from app.data_ingestion import load_transactions, build_monthly_features
from app.model import FEATURE_COLUMNS

DATA_PATH = BASE_DIR / "data" / "transactions.csv"
MODEL_DIR = BASE_DIR / "models"
MODEL_DIR.mkdir(exist_ok=True)

df = load_transactions(DATA_PATH)
monthly = build_monthly_features(df)

X = monthly[FEATURE_COLUMNS]
y = monthly["target_revenue"]

split_index = int(len(monthly) * 0.8)
X_train, X_test = X.iloc[:split_index], X.iloc[split_index:]
y_train, y_test = y.iloc[:split_index], y.iloc[split_index:]

categorical = ["country"]
numeric = [c for c in FEATURE_COLUMNS if c not in categorical]

preprocessor = ColumnTransformer(
    transformers=[
        ("country", OneHotEncoder(handle_unknown="ignore"), categorical),
        (
            "numeric",
            Pipeline(
                steps=[
                    ("imputer", SimpleImputer(strategy="median")),
                    ("scaler", StandardScaler()),
                ]
            ),
            numeric,
        ),
    ]
)

models = {
    "baseline_dummy": DummyRegressor(strategy="mean"),
    "linear_regression": LinearRegression(),
    "random_forest": RandomForestRegressor(
        n_estimators=150, random_state=42, max_depth=8
    ),
    "gradient_boosting": GradientBoostingRegressor(random_state=42),
}

results = {}
trained_models = {}

for name, estimator in models.items():
    pipeline = Pipeline(
        steps=[
            ("preprocessor", preprocessor),
            ("model", estimator),
        ]
    )
    pipeline.fit(X_train, y_train)
    predictions = pipeline.predict(X_test)
    mae = mean_absolute_error(y_test, predictions)
    results[name] = float(mae)
    trained_models[name] = pipeline

best_model_name = min(results, key=results.get)
best_model = trained_models[best_model_name]

joblib.dump(best_model, MODEL_DIR / "best_model.joblib")

metadata = {
    "best_model": best_model_name,
    "model_version": "1.0.0",
    "metric": "mean_absolute_error",
    "model_scores": results,
    "training_target_mean": float(y_train.mean()),
    "training_rows": int(len(X_train)),
    "test_rows": int(len(X_test)),
}

(MODEL_DIR / "model_metadata.json").write_text(
    json.dumps(metadata, indent=2), encoding="utf-8"
)

plt.figure(figsize=(8, 5))
names = list(results.keys())
scores = [results[n] for n in names]
plt.bar(names, scores)
plt.ylabel("Mean Absolute Error")
plt.title("Model Comparison Against Baseline")
plt.xticks(rotation=20, ha="right")
plt.tight_layout()
plt.savefig(MODEL_DIR / "model_comparison.png", dpi=160)
plt.close()

print(json.dumps(metadata, indent=2))
