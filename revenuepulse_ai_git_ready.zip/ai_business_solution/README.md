# AI Revenue Forecasting Business Solution

## Business idea

**RevenuePulse AI** is a deployable forecasting service for an online digital-content retailer.  
It predicts next-month revenue for a selected country or for all countries combined.

The solution follows an end-to-end AI workflow:

1. Business understanding
2. Automated data ingestion
3. Exploratory data analysis
4. Feature engineering
5. Baseline and multiple-model comparison
6. Model training and persistence
7. Flask API deployment
8. Unit testing
9. Logging and performance monitoring
10. Docker containerization

## Business value

Management can use the forecast to:

- plan marketing expenditure;
- allocate customer-support capacity;
- identify weak regional markets;
- prepare inventory and infrastructure;
- compare actual revenue with predicted revenue.

## Project structure

```text
ai_business_solution/
├── app/
│   ├── api.py
│   ├── data_ingestion.py
│   ├── model.py
│   └── monitoring.py
├── data/
│   └── transactions.csv
├── logs/
│   └── .gitkeep
├── models/
│   └── .gitkeep
├── scripts/
│   ├── run_all_tests.sh
│   └── train_model.py
├── tests/
│   ├── test_api.py
│   ├── test_ingestion.py
│   ├── test_logging.py
│   └── test_model.py
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── pytest.ini
├── .gitignore
└── README.md
```

## API input

Minimum required fields:

```json
{
  "country": "United Kingdom",
  "target_month": "2026-07"
}
```

Use `"ALL"` to obtain a forecast across all countries.

## API endpoints

### Health check

```bash
curl http://localhost:5000/health
```

### Prediction

```bash
curl -X POST http://localhost:5000/predict \
  -H "Content-Type: application/json" \
  -d '{"country":"United Kingdom","target_month":"2026-07"}'
```

All countries:

```bash
curl -X POST http://localhost:5000/predict \
  -H "Content-Type: application/json" \
  -d '{"country":"ALL","target_month":"2026-07"}'
```

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/train_model.py
python -m app.api
```

Windows activation:

```powershell
.venv\Scripts\activate
```

## Run tests

```bash
pytest
```

or:

```bash
bash scripts/run_all_tests.sh
```

The tests cover:

- API behavior and validation;
- model training and prediction;
- data ingestion;
- logging;
- isolation of test models and logs from production resources.

## Docker

Build and run:

```bash
docker build -t revenuepulse-ai .
docker run -p 5000:5000 revenuepulse-ai
```

Using Docker Compose:

```bash
docker compose up --build
```

## Monitoring

Each prediction writes a JSON line to `logs/predictions.log`, including:

- timestamp;
- country;
- target month;
- model version;
- prediction;
- input summary;
- runtime.

The monitoring module compares recent prediction distributions against the training baseline and returns a drift warning when the deviation exceeds a configurable threshold.

## Model comparison

The training script compares:

- DummyRegressor baseline;
- LinearRegression;
- RandomForestRegressor;
- GradientBoostingRegressor.

It saves:

- the best model;
- model metadata;
- a model-comparison chart.

## Push to GitHub

```bash
git init
git add .
git commit -m "Initial RevenuePulse AI solution"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/revenuepulse-ai.git
git push -u origin main
```

## Assumptions

- Historical monthly patterns are representative of near-term demand.
- Revenue can be forecast using country, month, year, prior-month revenue, views, purchases, and customer activity.
- The included dataset is synthetic and intended for demonstration and peer review.
