from app.monitoring import write_prediction_log, read_prediction_logs, detect_prediction_drift


def test_logging_isolated_from_production(tmp_path):
    log_path = tmp_path / "test_predictions.log"

    write_prediction_log(
        log_path,
        country="UK",
        target_month="2026-07",
        prediction=1200.0,
        model_version="test",
        runtime_ms=3.2,
        input_summary={"countries_scored": 1},
    )

    records = read_prediction_logs(log_path)
    assert len(records) == 1
    assert records[0]["country"] == "UK"


def test_drift_detection():
    records = [{"prediction": 200.0} for _ in range(10)]
    result = detect_prediction_drift(records, training_mean=100.0, threshold_ratio=0.3)
    assert result["drift_detected"] is True
