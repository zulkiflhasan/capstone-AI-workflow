import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

from app.model import FEATURE_COLUMNS, predict_revenue


def test_model_prediction():
    X = pd.DataFrame(
        [
            ["UK", 1, 2025, 100, 10, 1000, 5],
            ["UK", 2, 2025, 120, 11, 1100, 6],
            ["US", 1, 2025, 90, 8, 900, 4],
        ],
        columns=FEATURE_COLUMNS,
    )
    y = [120, 130, 100]

    pre = ColumnTransformer(
        [("country", OneHotEncoder(handle_unknown="ignore"), ["country"])],
        remainder="passthrough",
    )
    model = Pipeline([("preprocessor", pre), ("model", LinearRegression())])
    model.fit(X, y)

    value = predict_revenue(model, X.iloc[[0]])
    assert isinstance(value, float)
    assert value > 0
