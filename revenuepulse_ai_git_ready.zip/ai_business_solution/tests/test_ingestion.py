import pandas as pd
import pytest
from app.data_ingestion import load_transactions, build_monthly_features


def test_load_transactions_and_build_features(tmp_path):
    path = tmp_path / "sample.csv"
    path.write_text(
        "date,country,revenue,purchases,stream_views,customer_id\n"
        "2025-01-01,UK,100,2,50,C1\n"
        "2025-02-01,UK,120,3,60,C2\n"
        "2025-03-01,UK,130,4,70,C3\n"
    )

    df = load_transactions(path)
    monthly = build_monthly_features(df)

    assert not df.empty
    assert "target_revenue" in monthly.columns
    assert len(monthly) == 1


def test_missing_columns_raise_error(tmp_path):
    path = tmp_path / "bad.csv"
    path.write_text("date,country\n2025-01-01,UK\n")
    with pytest.raises(ValueError):
        load_transactions(path)
