import json
from pathlib import Path

import joblib
import pandas as pd
import pytest
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

import app.api as api_module
from app.model import FEATURE_COLUMNS


@pytest.fixture
def client(tmp_path, monkeypatch):
    data_path = tmp_path / "transactions.csv"
    rows = [
        ["2025-01-01", "United Kingdom", 100, 10, 1000, "C1"],
        ["2025-02-01", "United Kingdom", 120, 12, 1100, "C2"],
        ["2025-03-01", "United Kingdom", 140, 14, 1200, "C3"],
        ["2025-01-01", "USA", 90, 9, 900, "U1"],
        ["2025-02-01", "USA", 100, 10, 950, "U2"],
        ["2025-03-01", "USA", 110, 11, 1000, "U3"],
    ]
    pd.DataFrame(
        rows,
        columns=["date", "country", "revenue", "purchases", "stream_views", "customer_id"],
    ).to_csv(data_path, index=False)

    X = pd.DataFrame(
        [
            ["United Kingdom", 2, 2025, 100, 12, 1100, 1],
            ["United Kingdom", 3, 2025, 120, 14, 1200, 1],
            ["USA", 2, 2025, 90, 10, 950, 1],
            ["USA", 3, 2025, 100, 11, 1000, 1],
        ],
        columns=FEATURE_COLUMNS,
    )
    y = [120, 140, 100, 110]

    pre = ColumnTransformer(
        [("country", OneHotEncoder(handle_unknown="ignore"), ["country"])],
        remainder="passthrough",
    )
    model = Pipeline([("preprocessor", pre), ("model", LinearRegression())])
    model.fit(X, y)

    model_path = tmp_path / "model.joblib"
    metadata_path = tmp_path / "metadata.json"
    log_path = tmp_path / "predictions.log"

    joblib.dump(model, model_path)
    metadata_path.write_text(
        json.dumps(
            {
                "best_model": "linear_regression",
                "model_version": "test",
                "training_target_mean": 117.5,
            }
        )
    )

    monkeypatch.setattr(api_module, "DATA_PATH", data_path)
    monkeypatch.setattr(api_module, "MODEL_PATH", model_path)
    monkeypatch.setattr(api_module, "METADATA_PATH", metadata_path)
    monkeypatch.setattr(api_module, "LOG_PATH", log_path)

    api_module.app.config["TESTING"] = True
    return api_module.app.test_client()


def test_health(client):
    response = client.get("/health")
    assert response.status_code == 200


def test_predict_specific_country(client):
    response = client.post(
        "/predict",
        json={"country": "United Kingdom", "target_month": "2026-07"},
    )
    assert response.status_code == 200
    assert "predicted_revenue" in response.get_json()


def test_predict_all_countries(client):
    response = client.post(
        "/predict",
        json={"country": "ALL", "target_month": "2026-07"},
    )
    assert response.status_code == 200
    assert response.get_json()["country"] == "ALL"


def test_invalid_input(client):
    response = client.post("/predict", json={"country": "USA"})
    assert response.status_code == 400
